<?php return array (
  'step1' => 'App\\Http\\Livewire\\Step1',
  'step2' => 'App\\Http\\Livewire\\Step2',
  'step3' => 'App\\Http\\Livewire\\Step3',
  'wizard' => 'App\\Http\\Livewire\\Wizard',
);