<!DOCTYPE html>

<html>

<head>

    <title>Laravel Livewire Example - HDTuto.com</title>

    <?php echo \Livewire\Livewire::styles(); ?>


    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

  

    <link href="<?php echo e(asset('wizard.css')); ?>" rel="stylesheet" id="bootstrap-css">

</head>

<body>

    

<div class="container">

    

    <div class="card">

      <div class="card-header">

        Laravel Livewire TechCrista

      </div>

      <div class="card-body">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wizard', [])->html();
} elseif ($_instance->childHasBeenRendered('NbJpU1E')) {
    $componentId = $_instance->getRenderedChildComponentId('NbJpU1E');
    $componentTag = $_instance->getRenderedChildComponentTagName('NbJpU1E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NbJpU1E');
} else {
    $response = \Livewire\Livewire::mount('wizard', []);
    $html = $response->html();
    $_instance->logRenderedChild('NbJpU1E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

      </div>

    </div>

        

</div>

    

</body>

 

<?php echo \Livewire\Livewire::scripts(); ?>


  

</html><?php /**PATH C:\xampp\htdocs\multistep\resources\views/default.blade.php ENDPATH**/ ?>