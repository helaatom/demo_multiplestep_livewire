<div>

   

<?php if(!empty($successMessage)): ?>

<div class="alert alert-success">

   <?php echo e($successMessage); ?>


</div>

<?php endif; ?>

  

<div class="stepwizard">

    <div class="stepwizard-row setup-panel">

        <div class="stepwizard-step">

            <a href="#step-1" type="button" class="btn btn-circle <?php echo e($currentStep != 1 ? 'btn-default' : 'btn-primary'); ?>">1</a>

            <p>Step 1</p>

        </div>

        <div class="stepwizard-step">

            <a href="#step-2" type="button" class="btn btn-circle <?php echo e($currentStep != 2 ? 'btn-default' : 'btn-primary'); ?>">2</a>

            <p>Step 2</p>

        </div>

        <div class="stepwizard-step">

            <a href="#step-3" type="button" class="btn btn-circle <?php echo e($currentStep != 3 ? 'btn-default' : 'btn-primary'); ?>" disabled="disabled">3</a>

            <p>Step 3</p>

        </div>

    </div>

</div>

  

    <div class="row setup-content <?php echo e($currentStep != 1 ? 'displayNone' : ''); ?>" id="step-1">

        <div class="col-xs-12">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('step1', [])->html();
} elseif ($_instance->childHasBeenRendered('l2462756123-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2462756123-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2462756123-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2462756123-0');
} else {
    $response = \Livewire\Livewire::mount('step1', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2462756123-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>

    <div class="row setup-content <?php echo e($currentStep != 2 ? 'displayNone' : ''); ?>" id="step-2">

        <div class="col-xs-12">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('step2', [])->html();
} elseif ($_instance->childHasBeenRendered('l2462756123-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2462756123-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2462756123-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2462756123-1');
} else {
    $response = \Livewire\Livewire::mount('step2', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2462756123-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>

    <div class="row setup-content <?php echo e($currentStep != 3 ? 'displayNone' : ''); ?>" id="step-3">

        <div class="col-xs-12">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('step3', [])->html();
} elseif ($_instance->childHasBeenRendered('l2462756123-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l2462756123-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2462756123-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2462756123-2');
} else {
    $response = \Livewire\Livewire::mount('step3', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2462756123-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>

</div><?php /**PATH C:\xampp\htdocs\multistep\resources\views/livewire/wizard.blade.php ENDPATH**/ ?>